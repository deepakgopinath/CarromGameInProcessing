import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import pbox2d.*; 
import org.jbox2d.collision.shapes.*; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.*; 
import org.jbox2d.dynamics.joints.*; 
import org.jbox2d.collision.shapes.*; 
import org.jbox2d.collision.shapes.Shape; 
import org.jbox2d.dynamics.contacts.*; 
import ddf.minim.spi.*; 
import ddf.minim.signals.*; 
import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.ugens.*; 
import ddf.minim.effects.*; 

import org.jbox2d.collision.shapes.*; 
import org.jbox2d.pooling.normal.*; 
import org.slf4j.*; 
import pbox2d.*; 
import org.jbox2d.dynamics.contacts.*; 
import org.slf4j.impl.*; 
import org.jbox2d.callbacks.*; 
import org.jbox2d.dynamics.*; 
import org.jbox2d.common.*; 
import org.jbox2d.pooling.arrays.*; 
import org.jbox2d.pooling.stacks.*; 
import org.slf4j.helpers.*; 
import org.jbox2d.collision.*; 
import org.jbox2d.pooling.*; 
import org.jbox2d.collision.broadphase.*; 
import org.slf4j.spi.*; 
import org.jbox2d.dynamics.joints.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class CrazyCarrom extends PApplet {

                   //*******************Crazzzyyy Carrom*******************//
                    //*******************by DEEPAK GOPINATH******************//
                    
                    //************* Project 3 - Game Project ***************//
                    //********************  LMC 6310 ***********************//


///Goal is to pocket black carrom men and the queen. The queen has to be immediately followed up by the black. If white follows the queen, eventually you will lose
/// you can still continue to play and have fun!


//// Box2d physics library is used. You will have to download the add-on library PBox2D for this sketch to work.














//*************************************************//

//For the sounds..Minim library is being used.








//*************************************************//

PBox2D box2d; // Our 2-d world is declared.

//*************************************************//
Minim minim; // Our Minim object for sound stuff.
final int BUFFERSIZE = 256;

//*************************************************//
//Constants!!! 

final int SCREEN_WIDTH = 800;
final int SCREEN_HEIGHT = 600;

//*************************************************//
final int EDGE_SIZE= 40;
final int CARROM_BOARD_WIDTH = 640;
final int CARROM_BOARD_HEIGHT = 600;
final int CARROM_MEN_RADIUS = 14;
final int CARROM_STRIKER_RADIUS = 16;
final int CARROM_STRIKE_AREA_DIST_FROM_EDGE = 135;
final int OBS_LONG_DIM = 80;
final int OBS_SHORT_DIM = 13;

final float CARROM_MEN_VELOCITY_THRESHOLD = 0.3f;
final float CARROM_STRIKER_VELOCITY_THRESHOLD = 0.3f;
final int NUM_CARROM_WHITEMEN = 9;
final int NUM_CARROM_BLACKMEN = 9;
float [][] CARROM_WHITEMEN_COORD = new float[NUM_CARROM_WHITEMEN][2]; //Coordinates For the initial placement of the coins
float [][] CARROM_BLACKMEN_COORD = new float[NUM_CARROM_BLACKMEN][2];

final int IS_WHITE = 1;
final int IS_BLACK = 2;
final int IS_RED = 3;

//*************************************************//
final float LINEAR_DAMPING_CARROMMEN = 0.6f;
final float ANGULAR_DAMPING_CARROMMEN = 0.2f;

final float LINEAR_DAMPING_STRIKER = 0.7f;
final float ANGULAR_DAMPING_STRIKER = 0.2f;


//*************************************************//
//STRENGTH METER STUFF

final int MAX_SHOT_STRENGTH = 22000;
final int MIN_SHOT_STRENGTH = 0;

final int STRENGTH_METER_HEIGHT = 170;
final int STRENGTH_METER_WIDTH = 15;
final float STRENGTH_METER_XPOS = 700;
final float STRENGTH_METER_YPOS = SCREEN_HEIGHT/2;

//*************************************************//
//Pocket edges
final int POCKET_SIZE = 40;

final float TOP_RIGHT_LEFT_EDGE_X = CARROM_BOARD_WIDTH - EDGE_SIZE - POCKET_SIZE;
final float TOP_RIGHT_BOTTOM_EDGE_Y = EDGE_SIZE + POCKET_SIZE;

final float BOTTOM_RIGHT_LEFT_EDGE_X = CARROM_BOARD_WIDTH-EDGE_SIZE-POCKET_SIZE;
final float BOTTOM_RIGHT_TOP_EDGE_Y = CARROM_BOARD_HEIGHT - EDGE_SIZE -  POCKET_SIZE; 

final float BOTTOM_LEFT_RIGHT_EDGE_X = EDGE_SIZE + POCKET_SIZE;
final float BOTTOM_LEFT_TOP_EDGE_Y = CARROM_BOARD_HEIGHT - EDGE_SIZE -  POCKET_SIZE;

final float TOP_LEFT_RIGHT_EDGE_X = EDGE_SIZE + POCKET_SIZE;
final float TOP_LEFT_BOTTOM_EDGE_Y = EDGE_SIZE + POCKET_SIZE;

//*************************************************//
final float WORLD_GRAVITY = 0.4f; // Max gravity strength in any direction!

//*************************************************//

final int WIN_RESULT = 0;
final int LOSE_RESULT = 1;
final int MAX_STRIKER_CHANCES = 3;

//*************************************************//
final int FORCED_RESET = 1;
final int NATURAL_RESET = 2;
//*************************************************//

float currentStrengthFactor = 0;
float strengthFactorIncr = 0.005f;

//Some flags for different modes and checks for queen!
boolean isGravityOn = false;
boolean isAIModeOn = false;
boolean isQueenToBeShown = true;
boolean isGameOver = false;
boolean isQueenPocketed = false;
boolean isMute = true;
boolean isObsMove = false;

String queenStatus = "";
//*************************************************//

int whiteScored = 0;
int blackScored = 0;
int queenScoreB = 0;
int queenScoreW = 0;
int bonusPoint = 0;
int strikerChancesLeft = MAX_STRIKER_CHANCES;
int finalResult;

final int MAX_LEVEL = 1;

int level = 0; // current level

//*************************************************//

//Array declarations!
ArrayList<Boundary>boundaries;
ArrayList<Boundary>obstructions;
ArrayList<CarromMen>whiteMen;
ArrayList<CarromMen>blackMen;
ArrayList<String>whiteSounds; // To hold the sound files. 
ArrayList<String>blackSounds;
ArrayList<Integer>currentShotLog;

final int WHITE_SHOT = 1;
final int BLACK_SHOT = 2;
final int QUEEN_SHOT = 3;
final int STRIKER_SHOT = 4;


Striker striker;
String strikerSound;
Queen queen;
String queenSound;

//*************************************************//

final int OPENING_PAGE = 0;
final int CONTROLS_AND_RULES_PAGE = 1;
final int PLAY_PAGE = 2;
final int TRANSITION_PAGE = 3; // NEXT LEVEL Display page
int startFlag = OPENING_PAGE;

//*************************************************//
PImage bgImage; //background image

public void setup()
{
  size(SCREEN_WIDTH,SCREEN_HEIGHT);
  smooth();
  bgImage = loadImage("bgCarrom.png");
  bgImage.filter(ERODE);
 
  createWorld();
  createShotLogArray();
  setCoinCoords();
  getSoundsReady();
  getCoinsReady();
 
  if(level == 1)
  {
    addObstructions();
  }
  addBoundaries();
 
  textSize(16);
  textAlign(LEFT);
}




public void draw()
{
  background(0);
  
  
  if(startFlag == OPENING_PAGE)
  {
    displayOpeningPage();
  }else if(startFlag == CONTROLS_AND_RULES_PAGE)
  {
    displayHelpPage();
  }
  else if(startFlag == TRANSITION_PAGE)
  {
    displayTransitionPage();
  }
  else if(startFlag == PLAY_PAGE)
  {
    stroke(0);
    box2d.step(); // Needed for the 2d world to work!!! 
    image(bgImage,0,0);
    //drawPockets();
    displayCoins();
    removePocketed();
    if(striker.isDone()) // If striker is pocketed, reset everything!
    {
      resetAll(NATURAL_RESET);
    }
    if(checkIfMotionStopped() == true)
    { 
      if(striker.isMoving == true)
      {
        resetAll(NATURAL_RESET);
      }
    }
    
    if(!isGameOver)
    {
      getReadyToHit();
     
    }else
    {
      isAIModeOn = false;
      isGravityOn = false;
      displayGameOver(finalResult);
    }
    showStrengthMeter();
    drawGravityAndAIStatus();
    displayScore();
  }
}




class Boundary
{
  
  float posX;
  float posY;
  float boundaryWidth;
  float boundaryHeight;
  boolean isObs;
  float addX, addY, perlinStepSize;
  
  
  Body b; // reference to the rigid body
  
  Boundary(float posX_, float posY_, float width_, float height_, boolean isObstruction)
  {
    addX = addY = 0;
    posX = posX_; // the centers of the box
    posY = posY_;
    boundaryWidth = width_;
    boundaryHeight = height_;
    isObs = isObstruction;
    //Define the polygon. 
    PolygonShape sd = new PolygonShape();    
    float box2dW = box2d.scalarPixelsToWorld(boundaryWidth/2); // we need half widths for the next line
    float box2dH = box2d.scalarPixelsToWorld(boundaryHeight/2);     
    sd.setAsBox(box2dW, box2dH);  //Each of the edge is just a box ( a rectangle)

    //The body has been defined now. 
    BodyDef bd = new BodyDef();
    bd.type = BodyType.STATIC;
    bd.position.set(box2d.coordPixelsToWorld(posX, posY));
    b = box2d.createBody(bd);
    b.setUserData(this);
    // Now the polygonshape and body needs to be connected. through a fixture
    
    b.createFixture(sd, 1);
    
  }
  
  public void display()
  {
    fill(127,27, 29);
    stroke(0);
    rectMode(CENTER);
    addX = addY = 0;
    if(isObs && isObsMove)
    {
      moveObs();
    }
    
    rect(posX+addX, posY+addY, boundaryWidth, boundaryHeight);
  }
  
  public void moveObs()
  {
    if(frameCount%5 == 0 )
    {
      perlinStepSize +=  random(1);
      addX = map(noise(perlinStepSize), 0, 1, -40, 40);
      addY = map(noise(perlinStepSize + 3000), 0, 1, -32, 36);
    }
      
    b.setTransform(box2d.coordPixelsToWorld(posX+addX, posY+addY), 0);
  }
}
class CarromMen
{
  Body b;
  float radius;
  int col;
  AudioSample sound;
  
  CarromMen(float startX, float startY, float r, int whatIsIt, String soundFile)
  {
    radius = r;
    makebody(startX, startY, r);
    sound = minim.loadSample(soundFile, BUFFERSIZE);
    b.setUserData(this); //This is useful to retreive info about this class during collisions.
    if(whatIsIt == IS_BLACK)
    {
      col = color(80,80,80); 
    } 
    else if(whatIsIt == IS_WHITE)
    {
      col = color(224,181,52); 
    }else if(whatIsIt == IS_RED)
    {
      col = color(235,33,221); 
    }
    sound.mute(); 
  }
  
  public void display()
  {
    Vec2 pos = box2d.getBodyPixelCoord(b);
    float a = b.getAngle();
    pushMatrix();
    translate(pos.x, pos.y);
    rotate(a);
    fill(col);
    stroke(0);
    strokeWeight(1);
    ellipse(0, 0, 2*radius, 2*radius); // Draw the coin
    line(0,0,radius,0); // Draw the orientation pointer!
    popMatrix(); 
  }
  
  public void killBody()
  {
    box2d.destroyBody(b);
  }
  
  public boolean isDone()
  {
    Vec2 currentPos = box2d.getBodyPixelCoord(b);
    if(checkIfPocketed(currentPos.x, currentPos.y))
    {
      killBody();
      return true;
    } else {
    return false;
    }
  
  }
  
  public void makebody(float x,float y, float rad)
  {
    CircleShape c = new CircleShape();
    c.setRadius(box2d.scalarPixelsToWorld(rad));
    
    BodyDef bd = new BodyDef();
    bd.type = BodyType.DYNAMIC;
    bd.position.set(box2d.coordPixelsToWorld(x,y));
    b = box2d.createBody(bd);
    
    FixtureDef fd = new FixtureDef();
    fd.shape = c;
    fd.density = 0.1f;
    fd.friction = 0.2f;
    fd.restitution = random(40,50)/100;
    
    b.createFixture(fd);
    Vec2 linVel = new Vec2(0,0);
    b.setLinearVelocity(linVel);
    b.setLinearDamping(LINEAR_DAMPING_CARROMMEN);
    b.setAngularDamping(ANGULAR_DAMPING_CARROMMEN);
 
  }
  
  public float velocityRetrieve()
  {
    Vec2 linVel = b.getLinearVelocity();
    return linVel.length();
  }
  public void resetVelocity()
  {
    b.setLinearVelocity(new Vec2(0,0));
    b.setAngularVelocity(0);
  }
  
  public void attractToCenter(float centerX, float centerY) //For AI mode...
  {
    Vec2 worldTarget = box2d.coordPixelsToWorld(centerX, centerY); // target is the center of the baord;
    Vec2 bodyVec = b.getWorldCenter(); //Where is the body right now in world coordinates;
    
    worldTarget.subLocal(bodyVec); // Find the difference vector
    worldTarget.normalize();
    worldTarget.x *= (float)random(0,1);
    worldTarget.y *= (float)random(0,1);
    b.applyForce(worldTarget, bodyVec);
  }
  
  public void play()
  {
    sound.trigger();
  }
}

public void beginContact(Contact cp)
{
  Fixture f1 = cp.getFixtureA();
  Fixture f2 = cp.getFixtureB();
  
  Body b1 = f1.getBody();
  Body b2 = f2.getBody();
  
  Object o1 = b1.getUserData();
  Object o2 = b2.getUserData();
  
  if(!isMute)
  { 
    if(o1.getClass() == CarromMen.class && o2.getClass() == CarromMen.class) 
     {
       CarromMen c1 = (CarromMen)o1;
       c1.play();
       CarromMen c2 = (CarromMen)o2;
       c2.play();
     }
     if(o1.getClass() == Striker.class && o2.getClass() == CarromMen.class)
     {
       Striker c1 = (Striker)o1;
       c1.play();
       CarromMen c2 = (CarromMen)o2;
       c2.play();
     }
     if(o1.getClass() == CarromMen.class && o2.getClass() == Striker.class)
     {
       CarromMen c1 = (CarromMen)o1;
       c1.play();
       Striker c2 = (Striker)o2;
       c2.play();
     }
  }
}  

public void endContact(Contact cp)
{

}
public void keyPressed()
{
  if(key == 'G' || key == 'g') //Gravity toggle
  {
   
    if(!isGravityOn)
    { 
      float x = random(-WORLD_GRAVITY, WORLD_GRAVITY);
      float y = random(-WORLD_GRAVITY, WORLD_GRAVITY);
      //println(x + " " + y);
      box2d.setGravity(x, y);
    }else
    { 
      box2d.setGravity(0,0);
    }
    isGravityOn = !isGravityOn;
  }
  
  if(key == ' ') // Space bar to launch the striker in the play page
  {
    if(startFlag == PLAY_PAGE)
    {
      if(checkIfMotionStopped())
      { 
        //println("here");
        striker.shotStrength = currentStrengthFactor*(MAX_SHOT_STRENGTH - MIN_SHOT_STRENGTH) + MIN_SHOT_STRENGTH;
        if(strikerChancesLeft > 0)
          striker.hit();
      }
    }else
    {
      if(startFlag == TRANSITION_PAGE)
      {
        startFlag = PLAY_PAGE;
      }
      else
      {
        startFlag++;
      }
    }
  }
  
  
    if(key == 'A' || key == 'a')
    {
      isAIModeOn = !isAIModeOn;
    }

  if(key == 'F' || key == 'f')
  {
    bonusPoint--; // Forced reset will decrement the bonus point.
    resetAll(FORCED_RESET);
  }
  
  if(key == 'H' || key == 'h')
  {
    startFlag = CONTROLS_AND_RULES_PAGE;
  }
  if(key == 'M' || key == 'm')
  {
    isMute = !isMute;
  }
  
  if(key == 'J' || key == 'j')
  {
    isObsMove = !isObsMove;
  }
}


public void getReadyToHit() //Position the striker...
{ 
  if(checkIfMotionStopped())
  {
    if(mousePressed)
      {  
          striker.moveAlongXAndSetShotDirection(mouseX, mouseY);
      }
  }
}


public void  displayOpeningPage()
{
    fill(255,25, 0);
    textAlign(CENTER);
    textSize(38);
    text("CRazzYyY CArroM", width/2 , height/2 - 100);
    textSize(22);
    text("CrEAted bY", width/2, height/2 - 40);
    textSize(28);
    text("DeEpaK goPiNatH", width/2, height/2 + 15 );
    textSize(20);
    fill(255,255,0);
    text("Hit Space to Continue", width/2, height/2 + 190);
    textSize(16);
    textAlign(LEFT);
}

public void displayHelpPage()
{
    fill(255, 25, 0);
    textAlign(CENTER);
    textSize(30);
    text("RuLeS aND cOnTRoLs", width/2, height/2 - 250);
    textSize(18);
    
    text("The objective of the game is to pocket the queen and all the black carrom men", width/2, height/2 - 190);
    text("The striker is set in motion by a sling shot, using the mouse. Hit spacebar to launch", width/2, height/2 - 150);
    text("Press 'G' to toggle the gravity mode. An invisible gravitational force in a random direction", width/2, height/2 - 110);
    text("will be activated", width/2, height/2 - 80);
    text("Press 'A' to toggle AI mode. The carrom men and the queen will begin to flock to the center", width/2, height/2 -40);
    //text("Note: This mode remains activated in Level 2", width/2, height/2 - 10);
    text("Press 'F' for forced striker reset, -1 on bonus", width/2, height/2);
    text("Press 'H' for help", width/2, height/2 + 30);
    text("Press 'M' for mute/unmute", width/2, height/2 + 60);
    text("Press 'J' for obstruction jiggle", width/2, height/2 + 90);
    text("Note: Level 2 implements constantly changing physics parameters ", width/2, height/2 + 120);
    text("for the carrom men and striker", width/2, height/2+150);
    
    
    fill(255,255,0);
    textSize(20);
    text("Hit Space to Continue", width/2, height/2 + 190);
    textAlign(LEFT);
    textSize(16);
}
public void displayTransitionPage()
{
   textSize(42);
   fill(0,0,0,80);
   rect(CARROM_BOARD_WIDTH/2,CARROM_BOARD_HEIGHT/2,CARROM_BOARD_WIDTH, CARROM_BOARD_HEIGHT); 
   fill(0,255,0);
   textAlign(CENTER);
   text("L E V E L    T W O", width/2, height/2);
   fill(255,255,0);
   textSize(20);
   text("Press Space to Continue", width/2, height/2 + 190);
   textAlign(LEFT);
   textSize(16);
}
public void showStrengthMeter()
{
  stroke(255);
  strokeWeight(2);
  fill(0);
  rect(STRENGTH_METER_XPOS, height/2, STRENGTH_METER_WIDTH, STRENGTH_METER_HEIGHT);
  fill(255,0,0);
  noStroke();
  rect(STRENGTH_METER_XPOS,height/2 + (1-currentStrengthFactor)*STRENGTH_METER_HEIGHT/2 ,STRENGTH_METER_WIDTH, currentStrengthFactor*STRENGTH_METER_HEIGHT);
  text("Strength", STRENGTH_METER_XPOS - 30, STRENGTH_METER_YPOS + STRENGTH_METER_HEIGHT/2 + 20);
}

public void drawGravityAndAIStatus()
{
  fill(255,0,0);
  if(isGravityOn)
  {
    text("GRAVITY ON",STRENGTH_METER_XPOS - 50, 30);
  }else
  {
    text("GRAVITY OFF",STRENGTH_METER_XPOS -50, 30);
  } 
  
  if(isAIModeOn)
  {
    text("AI ON", STRENGTH_METER_XPOS - 50, 50);
  }else
  {
    text("AI OFF", STRENGTH_METER_XPOS - 50, 50);
  }
}

public void drawPockets()
{
   line(CARROM_BOARD_WIDTH-EDGE_SIZE-POCKET_SIZE, EDGE_SIZE,CARROM_BOARD_WIDTH-EDGE_SIZE-POCKET_SIZE , EDGE_SIZE+POCKET_SIZE);
   line(CARROM_BOARD_WIDTH-EDGE_SIZE-POCKET_SIZE, EDGE_SIZE+POCKET_SIZE,CARROM_BOARD_WIDTH-EDGE_SIZE,EDGE_SIZE+POCKET_SIZE);
   
   line(CARROM_BOARD_WIDTH-EDGE_SIZE-POCKET_SIZE, CARROM_BOARD_HEIGHT-EDGE_SIZE-POCKET_SIZE, CARROM_BOARD_WIDTH-EDGE_SIZE-POCKET_SIZE, CARROM_BOARD_HEIGHT-EDGE_SIZE);
   line(CARROM_BOARD_WIDTH-EDGE_SIZE-POCKET_SIZE,CARROM_BOARD_HEIGHT-EDGE_SIZE-POCKET_SIZE, CARROM_BOARD_WIDTH-EDGE_SIZE, CARROM_BOARD_HEIGHT-EDGE_SIZE-POCKET_SIZE);
   
   line(EDGE_SIZE, CARROM_BOARD_HEIGHT-EDGE_SIZE-POCKET_SIZE, EDGE_SIZE+POCKET_SIZE,CARROM_BOARD_HEIGHT-EDGE_SIZE-POCKET_SIZE);
   line(EDGE_SIZE+POCKET_SIZE,CARROM_BOARD_HEIGHT-EDGE_SIZE-POCKET_SIZE,EDGE_SIZE+POCKET_SIZE,CARROM_BOARD_HEIGHT-EDGE_SIZE);
   
   line(EDGE_SIZE,EDGE_SIZE+POCKET_SIZE,EDGE_SIZE+POCKET_SIZE,EDGE_SIZE+POCKET_SIZE);
   line(EDGE_SIZE+POCKET_SIZE,EDGE_SIZE,EDGE_SIZE+POCKET_SIZE,EDGE_SIZE+POCKET_SIZE);
}

public void displayCoins()
{
  for(Boundary edge : boundaries)
  {
    edge.display();
  }
  if(level == 1)
  {
    for( Boundary obs : obstructions)
    {
      obs.display();
    }
  }
  
  for(CarromMen whiteM : whiteMen)
  {
    if(isAIModeOn)
    {
      whiteM.attractToCenter(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT/2);
    }
    whiteM.display();
  }
  for(CarromMen blackM : blackMen)
  {
    if(isAIModeOn)
    {
      blackM.attractToCenter(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT/2);
    }
    blackM.display();
  }
  
  if(isAIModeOn)
  {    
    queen.attractToCenter(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT/2);
  }
  if(isQueenToBeShown && !isQueenPocketed)
  {
    queen.display();
  }
  striker.display();
}

public void displayScore()
{
   text("W" + " "+str(whiteScored+queenScoreW), STRENGTH_METER_XPOS - 50, 80);
   text("B"+ "  "+str(blackScored+queenScoreB), STRENGTH_METER_XPOS - 50, 100);
   text("BONUS" + "  " + str(bonusPoint), STRENGTH_METER_XPOS - 50, 130);
   text("TOTAL" + "  " + str(blackScored+queenScoreB+bonusPoint), STRENGTH_METER_XPOS - 50, 160);
   text("STRIKER LEFT " + strikerChancesLeft, STRENGTH_METER_XPOS - 50, 200);
   text("'H' for Help ", STRENGTH_METER_XPOS - 50, 440);
   if(isMute)
   {
     text("Sound OFF",STRENGTH_METER_XPOS - 50, 480);
   }
   else
   {
     text("Sound ON",STRENGTH_METER_XPOS - 50, 480);
   }
   text(queenStatus , STRENGTH_METER_XPOS - 50, 510);
   text("LEVEL: " + str(level+1), STRENGTH_METER_XPOS - 50, 530);
   text("Motion Status: " , STRENGTH_METER_XPOS -50, 560);
   if(checkIfMotionStopped())
   {
      text("Not Moving" , STRENGTH_METER_XPOS -50, 580);
   }
   else
   {
     text("Moving ", STRENGTH_METER_XPOS -50, 580);
   }
}

public void displayGameOver(int result)
{
   textSize(42);
   fill(0,0,0,80);
   rect(CARROM_BOARD_WIDTH/2,CARROM_BOARD_HEIGHT/2,CARROM_BOARD_WIDTH, CARROM_BOARD_HEIGHT); 
   isAIModeOn = false;
   isGravityOn = false;
   isObsMove = false; 
   fill(0,255,0);
   if(result == LOSE_RESULT)
  {
    text("G A M E   O V E R", CARROM_BOARD_WIDTH/2 - 170, CARROM_BOARD_HEIGHT/2);
  }else if (result == WIN_RESULT)
  {
    text("Y  O  U    W  I  N", CARROM_BOARD_WIDTH/2 - 170, CARROM_BOARD_HEIGHT/2);
  }
   textSize(16);
}
class Queen extends CarromMen
{
  Queen(float startX, float startY, float r, int whatIsIt, String soundFile)
  {
    super(startX, startY, r, whatIsIt, soundFile);
  }
  
  public boolean isDone()
  {
    Vec2 currentPos = box2d.getBodyPixelCoord(b);  
    return checkIfPocketed(currentPos.x, currentPos.y);
  }
  public void killBody()
  {
    box2d.destroyBody(b);
  }
  public void resetToCenter()
  {
    Vec2 centerPosition = box2d.coordPixelsToWorld(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT/2);
    b.setTransform(centerPosition, 0);
  }
}
public void createWorld()
{
  box2d = new PBox2D(this);
  box2d.createWorld();
  box2d.setGravity(0,0);
  box2d.listenForCollisions();
 
  minim = new Minim(this);
}
public void addBoundaries()
{
  boundaries = new ArrayList<Boundary>();
  boundaries.add(new Boundary(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT - EDGE_SIZE/2, CARROM_BOARD_WIDTH, EDGE_SIZE, false));
  boundaries.add(new Boundary(CARROM_BOARD_WIDTH/2, EDGE_SIZE/2, CARROM_BOARD_WIDTH, EDGE_SIZE, false));
  boundaries.add(new Boundary(CARROM_BOARD_WIDTH - EDGE_SIZE/2, CARROM_BOARD_HEIGHT/2, EDGE_SIZE, CARROM_BOARD_HEIGHT, false));
  boundaries.add(new Boundary(EDGE_SIZE/2, CARROM_BOARD_HEIGHT/2, EDGE_SIZE, CARROM_BOARD_HEIGHT, false)); 

}

public void setCoinCoords()
{
  float x = CARROM_MEN_RADIUS;
  float offsetW = CARROM_BOARD_WIDTH/2;
  float offsetH = CARROM_BOARD_HEIGHT/2 - 5;
   
  if(level == 0) // standard coin arrangement
  {
  
    CARROM_WHITEMEN_COORD[0][0] = offsetW; CARROM_WHITEMEN_COORD[0][1] = offsetH + 2*x;
    CARROM_WHITEMEN_COORD[1][0] = offsetW; CARROM_WHITEMEN_COORD[1][1] = offsetH + 4*x;
    CARROM_WHITEMEN_COORD[2][0] = offsetW; CARROM_WHITEMEN_COORD[2][1] = offsetH - 4*x;
    
    CARROM_WHITEMEN_COORD[3][0] = offsetW + sqrt(3)*x ; CARROM_WHITEMEN_COORD[3][1] = offsetH - x;
    CARROM_WHITEMEN_COORD[4][0] = offsetW - sqrt(3)*x ; CARROM_WHITEMEN_COORD[4][1] = offsetH - x;
    
    CARROM_WHITEMEN_COORD[5][0] = offsetW + 2*sqrt(3)*x ; CARROM_WHITEMEN_COORD[5][1] = offsetH - 2*x;
    CARROM_WHITEMEN_COORD[6][0] = offsetW + 2*sqrt(3)*x ; CARROM_WHITEMEN_COORD[6][1] = offsetH + 2*x;
    
    CARROM_WHITEMEN_COORD[7][0] = offsetW - 2*sqrt(3)*x ; CARROM_WHITEMEN_COORD[7][1] = offsetH - 2*x;
    CARROM_WHITEMEN_COORD[8][0] = offsetW - 2*sqrt(3)*x ; CARROM_WHITEMEN_COORD[8][1] = offsetH + 2*x;
 
  //*************
  
  
    CARROM_BLACKMEN_COORD[0][0] = offsetW; CARROM_BLACKMEN_COORD[0][1] = offsetH - 2*x;
    
    CARROM_BLACKMEN_COORD[1][0] = offsetW + sqrt(3)*x; CARROM_BLACKMEN_COORD[1][1] = offsetH - 1.5f*x;
    CARROM_BLACKMEN_COORD[2][0] = offsetW + sqrt(3)*x; CARROM_BLACKMEN_COORD[2][1] = offsetH + x;
    CARROM_BLACKMEN_COORD[3][0] = offsetW + sqrt(3)*x; CARROM_BLACKMEN_COORD[3][1] = offsetH + 1.5f*x;
    
    CARROM_BLACKMEN_COORD[4][0] = offsetW - sqrt(3)*x; CARROM_BLACKMEN_COORD[4][1] = offsetH - 1.5f*x;
    CARROM_BLACKMEN_COORD[5][0] = offsetW - sqrt(3)*x; CARROM_BLACKMEN_COORD[5][1] = offsetH + x;
    CARROM_BLACKMEN_COORD[6][0] = offsetW - sqrt(3)*x; CARROM_BLACKMEN_COORD[6][1] = offsetH + 1.5f*x;
    
    CARROM_BLACKMEN_COORD[7][0] = offsetW + 2*sqrt(3)*x; CARROM_BLACKMEN_COORD[7][1] = offsetH;
    CARROM_BLACKMEN_COORD[8][0] = offsetW - 2*sqrt(3)*x; CARROM_BLACKMEN_COORD[8][1] = offsetH;
  }
  if(level != 0) //white and black flipped in std coin arrangement
  {
    CARROM_BLACKMEN_COORD[0][0] = offsetW; CARROM_BLACKMEN_COORD[0][1] = offsetH + 2*x;
    CARROM_BLACKMEN_COORD[1][0] = offsetW; CARROM_BLACKMEN_COORD[1][1] = offsetH + 4*x;
    CARROM_BLACKMEN_COORD[2][0] = offsetW; CARROM_BLACKMEN_COORD[2][1] = offsetH - 4*x;
    
    CARROM_BLACKMEN_COORD[3][0] = offsetW + sqrt(3)*x ; CARROM_BLACKMEN_COORD[3][1] = offsetH - x;
    CARROM_BLACKMEN_COORD[4][0] = offsetW - sqrt(3)*x ; CARROM_BLACKMEN_COORD[4][1] = offsetH - x;
    
    CARROM_BLACKMEN_COORD[5][0] = offsetW + 2*sqrt(3)*x ; CARROM_BLACKMEN_COORD[5][1] = offsetH - 2*x;
    CARROM_BLACKMEN_COORD[6][0] = offsetW + 2*sqrt(3)*x ; CARROM_BLACKMEN_COORD[6][1] = offsetH + 2*x;
    
    CARROM_BLACKMEN_COORD[7][0] = offsetW - 2*sqrt(3)*x ; CARROM_BLACKMEN_COORD[7][1] = offsetH - 2*x;
    CARROM_BLACKMEN_COORD[8][0] = offsetW - 2*sqrt(3)*x ; CARROM_BLACKMEN_COORD[8][1] = offsetH + 2*x;
    
    
    
    CARROM_WHITEMEN_COORD[0][0] = offsetW; CARROM_WHITEMEN_COORD[0][1] = offsetH - 2*x;
    
    CARROM_WHITEMEN_COORD[1][0] = offsetW + sqrt(3)*x; CARROM_WHITEMEN_COORD[1][1] = offsetH - 1.5f*x;
    CARROM_WHITEMEN_COORD[2][0] = offsetW + sqrt(3)*x; CARROM_WHITEMEN_COORD[2][1] = offsetH + x;
    CARROM_WHITEMEN_COORD[3][0] = offsetW + sqrt(3)*x; CARROM_WHITEMEN_COORD[3][1] = offsetH + 1.5f*x;
    
    CARROM_WHITEMEN_COORD[4][0] = offsetW - sqrt(3)*x; CARROM_WHITEMEN_COORD[4][1] = offsetH - 1.5f*x;
    CARROM_WHITEMEN_COORD[5][0] = offsetW - sqrt(3)*x; CARROM_WHITEMEN_COORD[5][1] = offsetH + x;
    CARROM_WHITEMEN_COORD[6][0] = offsetW - sqrt(3)*x; CARROM_WHITEMEN_COORD[6][1] = offsetH + 1.5f*x;
    
    CARROM_WHITEMEN_COORD[7][0] = offsetW + 2*sqrt(3)*x; CARROM_WHITEMEN_COORD[7][1] = offsetH;
    CARROM_WHITEMEN_COORD[8][0] = offsetW - 2*sqrt(3)*x; CARROM_WHITEMEN_COORD[8][1] = offsetH;
    
  }
  
}

public void  getCoinsReady()
{
  whiteMen = new ArrayList<CarromMen>();
  for(int i=0; i<NUM_CARROM_WHITEMEN; i++)
  {
    whiteMen.add(new CarromMen(CARROM_WHITEMEN_COORD[i][0], CARROM_WHITEMEN_COORD[i][1], CARROM_MEN_RADIUS, IS_WHITE, (String)whiteSounds.get(i)));
  }
  
  blackMen = new ArrayList<CarromMen>();
  for(int i=0; i<NUM_CARROM_BLACKMEN; i++)
  {
    blackMen.add(new CarromMen(CARROM_BLACKMEN_COORD[i][0],CARROM_BLACKMEN_COORD[i][1], CARROM_MEN_RADIUS, IS_BLACK, (String)blackSounds.get(i)));
  }
  
  striker = new Striker(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT - CARROM_STRIKE_AREA_DIST_FROM_EDGE, CARROM_STRIKER_RADIUS, strikerSound);
  queen = new Queen(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT/2 - 5, CARROM_MEN_RADIUS, IS_RED, queenSound);

}

public void createShotLogArray()
{
  currentShotLog = new ArrayList<Integer>();
}

public void getSoundsReady()
{
  whiteSounds = new ArrayList<String>();
  for(int i=0; i<NUM_CARROM_WHITEMEN; i++)
  {
    String soundFileName = "W" + str(i+1) + ".wav";
    whiteSounds.add(soundFileName);
  }
  
  blackSounds = new ArrayList<String>();
  for(int i=0; i<NUM_CARROM_BLACKMEN; i++)
  {
    String soundFileName = "B" + str(i+1) + ".wav";
    blackSounds.add(soundFileName);
  }
  
  strikerSound = "S.wav";
  queenSound = "Q.wav";
}

public void addObstructions()
{
   obstructions = new ArrayList<Boundary>();
  
  obstructions.add(new Boundary(CARROM_BOARD_WIDTH/4, CARROM_BOARD_HEIGHT/4, OBS_LONG_DIM + random(5), OBS_SHORT_DIM + random(5), true));
  obstructions.add(new Boundary(CARROM_BOARD_WIDTH/4 - 10, 3*CARROM_BOARD_HEIGHT/4 - 30, OBS_SHORT_DIM + random(5), OBS_LONG_DIM + random(5), true));
  obstructions.add(new Boundary(3*CARROM_BOARD_WIDTH/4,  CARROM_BOARD_HEIGHT/4, OBS_SHORT_DIM + random(5), OBS_LONG_DIM + random(5), true));
  obstructions.add(new Boundary(3*CARROM_BOARD_WIDTH/4 + 30, 3*CARROM_BOARD_HEIGHT/4 - 10 , OBS_LONG_DIM + random(5), OBS_SHORT_DIM + random(5), true)); 
}
class Striker
{
  Body b;
  float radius;
  int col;
  boolean isMoving;
  float anglePointer;
  float shotStrength;
  float aimVectorLength;
  AudioSample sound;
  boolean isWithinTranslationDist;
  
  Striker(float startX, float startY, float r, String soundFile)
  {
    radius = r;
    makebody(startX, startY, radius);
    b.setUserData(this);
    col = color(230,221,197);
    sound = minim.loadSample(soundFile, BUFFERSIZE);
    isMoving = false;
    anglePointer = -PI/2;
    shotStrength = MIN_SHOT_STRENGTH;
    isWithinTranslationDist = true;
    sound.mute();
  }
  
  public void display()
  {
    Vec2 pos = box2d.getBodyPixelCoord(b);
    anglePointer = b.getAngle();
    float a = b.getAngle();
    pushMatrix();
    translate(pos.x, pos.y);
    rotate(a);
    fill(col);
    stroke(0);
    strokeWeight(1);
    ellipse(0, 0, 2*radius, 2*radius);
    
    if(!isMoving && isWithinTranslationDist == false) // if outside the translation zone draw the sling shot. 
    {
      pushMatrix();
      translate(0, radius); // draw the sling shot. 
      float rotAngle = atan(radius/aimVectorLength);
      float distance = sqrt(pow(radius,2) + pow(aimVectorLength,2));
      rotate(-rotAngle);
      line(0,0, distance, 0);
      rotate(rotAngle);
      translate(0,-2*radius);
      rotate(rotAngle);
      line(0,0, distance, 0);
      popMatrix();
      
    }
    popMatrix(); 
  }
  public void makebody(float x, float y, float r)
  {
    CircleShape c = new CircleShape();
    c.setRadius(box2d.scalarPixelsToWorld(r));
    
    BodyDef bd = new BodyDef();
    bd.type = BodyType.DYNAMIC;
    bd.position.set(box2d.coordPixelsToWorld(x,y));
    b = box2d.createBody(bd);
    
    FixtureDef fd = new FixtureDef();
    fd.shape = c;
    fd.density = 0.3f;
    fd.friction = 0.2f;
    fd.restitution = random(60,80)/100.0f;
    
    b.createFixture(fd);
    Vec2 linVel = new Vec2(0,0);
    b.setLinearVelocity(linVel);
    b.setLinearDamping(LINEAR_DAMPING_STRIKER);
    b.setAngularDamping(ANGULAR_DAMPING_STRIKER);
    b.setGravityScale(0);
  }

  public float velocityRetrieve()
  {
    Vec2 linVel = b.getLinearVelocity();
    return linVel.length();
  }
  public void resetPosition()
  {
   // b.setType(BodyType.STATIC); // so that on reset it doesnt move the coins in the way
    b.setActive(false);
    b.setLinearVelocity(new Vec2(0,0));
    b.setAngularVelocity(0);
    anglePointer = -PI/2;
    shotStrength = MIN_SHOT_STRENGTH;
    Vec2 position = new Vec2(box2d.coordPixelsToWorld(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT - CARROM_STRIKE_AREA_DIST_FROM_EDGE));
    b.setTransform(position, anglePointer);
    isWithinTranslationDist =  true;
    isMoving = false;
  }
  public void killBody()
  {
    box2d.destroyBody(b);
  }
 public boolean isDone()
  {
    Vec2 currentPos = box2d.getBodyPixelCoord(b);
    if(checkIfPocketed(currentPos.x, currentPos.y)) // if striker goes in pocket, reduce the chances left. 
    {
      strikerChancesLeft--;
      if(strikerChancesLeft == 0)
      {
        isGameOver = true;
        finalResult = LOSE_RESULT;
      }
      return true;
    }else
    {
      return false;
    }
  }  

  public void moveAlongXAndSetShotDirection(float mousePosX, float mousePosY)
  {  
    Vec2 mousePosInWorld = box2d.coordPixelsToWorld(mousePosX, mousePosY);
    Vec2 bodyPos = b.getWorldCenter();
    Vec2 bodyPosInPixels = box2d.coordWorldToPixels(bodyPos);
    //println(mousePosInWorld.x + " " + mousePosInWorld.y + " " + bodyPos.x + " " + bodyPos.y);
    //if the mouse is within the striker area only do translation if is it outside do rotation
    if(dist(mouseX, mouseY, bodyPosInPixels.x, bodyPosInPixels.y) <= 2*CARROM_STRIKER_RADIUS) // if within the translation zone move along x.
    {
      isWithinTranslationDist = true;
      bodyPos.x = mousePosInWorld.x;
      if(bodyPos.x < -22.42f )
      {
        bodyPos.x = -22.42f;
      }
      if(bodyPos.x > 7.22f)
      {
        bodyPos.x = 7.22f;
      }
      aimVectorLength = 0;
    }else // if outside the translation zone the rotate the striker.
    {
      isWithinTranslationDist = false;
      anglePointer = atan2(mouseY - bodyPosInPixels.y, mouseX - bodyPosInPixels.x); //atan2 calculates the angle between mouse position and the body center.
      aimVectorLength = dist(mouseX, mouseY, bodyPosInPixels.x, bodyPosInPixels.y);
    }
   
    aimVectorLength = constrain(aimVectorLength, 32, 105); // restrict the range of the aimVector. 
    //println(aimVectorLength);
    currentStrengthFactor = abs(map(aimVectorLength, 32, 105, 0, 1)); //use the aimVector to get the strength of the shot
    //println(currentStrengthFactor);
    b.setTransform(bodyPos, anglePointer);
  }
  
  public void hit()
  {
    currentShotLog.clear(); // Clear the shot log before every hit.
    b.setType(BodyType.DYNAMIC); // set dynamic type
    b.setActive(true);
    isMoving = true;
    unmuteSounds();
    if(level == 1)
    {
      randomizePhysicsParams();
      randomizePhysicsParamsCarromMen();
    }
    
    Vec2 impulse = new Vec2(shotStrength*cos(-anglePointer+PI), shotStrength*sin(-anglePointer+PI)); // the shot impulse is the opposite direction of the aimVector
    b.applyForceToCenter(impulse);
    aimVectorLength = 0; // reset the aimVector and the strength for next shot
    currentStrengthFactor = 0;
  }
  
  public void randomizePhysicsParams()
  {
      b.setLinearDamping(random(3*LINEAR_DAMPING_STRIKER) + 0.1f);
      b.setAngularDamping(random(3*ANGULAR_DAMPING_STRIKER) + 0.1f);
      b.getFixtureList().setRestitution(random(1));
  }
  
  public void play()
  {
    sound.trigger();
  }
}
public boolean checkIfMotionStopped()
{
//  checkIfQueenIsPocketedForSure();
  if(isGravityOn == false && isAIModeOn == false) // if gravity and AI is on the check for motion is done only on striker
  {
    if(striker.velocityRetrieve() > CARROM_MEN_VELOCITY_THRESHOLD)
    {
      return false;
    }
    else if(queen.velocityRetrieve() > CARROM_MEN_VELOCITY_THRESHOLD && isQueenToBeShown == true)
    {
      return false;
    }
    else
    {
        for(CarromMen whiteM : whiteMen)
        {
          if(whiteM.velocityRetrieve() > CARROM_STRIKER_VELOCITY_THRESHOLD)
            return false;
        }
        for(CarromMen blackM : blackMen)
        {
          if(blackM.velocityRetrieve() > CARROM_STRIKER_VELOCITY_THRESHOLD)
            return false;
        }
        return true;
    }
  }else if(isGravityOn == true || isAIModeOn == true)
  {
    if(striker.velocityRetrieve() > CARROM_MEN_VELOCITY_THRESHOLD)
    {
      return false;
    }else
    {
      return true;
    }
  }
  return true;
}

public boolean checkIfPocketed(float x, float y)
{
  if((x > TOP_RIGHT_LEFT_EDGE_X && y < TOP_RIGHT_BOTTOM_EDGE_Y) ||
     (x > BOTTOM_RIGHT_LEFT_EDGE_X && y > BOTTOM_RIGHT_TOP_EDGE_Y) ||
     (x < BOTTOM_LEFT_RIGHT_EDGE_X && y > BOTTOM_LEFT_TOP_EDGE_Y) ||
     (x < TOP_LEFT_RIGHT_EDGE_X && y < TOP_LEFT_BOTTOM_EDGE_Y))
  {
    return true;
  }else
  {
    return false;
  }
}


public void checkStrengthFactorBounds()
{
  if(currentStrengthFactor > 1)
  {
    currentStrengthFactor = 1;
    strengthFactorIncr *= -1.0f;
  }
  if(currentStrengthFactor < 0)
  {
    currentStrengthFactor = 0;
    strengthFactorIncr *= -1.0f;
  }
}

public boolean checkIfQueenIsPocketedForReal()
{
  if(isQueenToBeShown == true) // the queen is still on the board
  {
    return false; // So queen is not pocketed
  }
  else if(isQueenToBeShown == false && isQueenPocketed == false)  //Queen went in the pocket but awaiting confirmation. HAs not been followed up yet
  {  
    if(currentShotLog.size() > 0) // If at least one coin was pocketed in this shot
    {
      if(currentShotLog.contains(new Integer(QUEEN_SHOT)))
      {
        if(currentShotLog.size() == 1) // Only the queen was pocketed in this shot
        {
          return false;
        }else if(currentShotLog.size() > 1) // If there are more one 1 coin pocketed in a shot
        {
          int indexOfQueen = currentShotLog.indexOf(new Integer(QUEEN_SHOT));
          if(indexOfQueen == currentShotLog.size()-1) // If red was the last coin to be pocketed return, as we cannot decide it yet,
          {
            return false;
          }else
          { 
            if((Integer)currentShotLog.get(indexOfQueen + 1).intValue()== BLACK_SHOT)
            {
              isQueenPocketed = true; // The queen was pocketed for real. no need to instantiate a new queen. 
              queenScoreB = 2; // Because we have the red followed by black, increase black's score by 2
              queenStatus = "Queen Status: B";
              return true;
            }else
            {
              queenStatus = "Queen Status: W"; // The queen was pockted for real but by white. therefore increment white's score by 2. 
              isQueenPocketed = true;
              queenScoreW = 2;
              return true;
             
            }
          }
        }  
      }else
      {
        if(currentShotLog.get(0) == BLACK_SHOT) // The red was pocketed earlier. check if the first coin in this shot was pocketed. 
        {
          isQueenPocketed = true; // pocketed for real.
          queenScoreB = 2;
          queenStatus = "Queen Status: B";
          return true;
        }
        else if(currentShotLog.get(0) == WHITE_SHOT)
        { 
          isQueenPocketed = true;
          queenScoreW = 2;
          queenStatus = "Queen Status: W";
          return true;
//          queen = new Queen(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT/2 - 5, CARROM_MEN_RADIUS, IS_RED, queenSound);
//          return false; 
        }
        
      }
    }else
    { 
      // If no coin was pokcted in this shot and the queen was pocketed in the previous shot the queen has to be reset to the center as it was not successfully followed up with a black
      isQueenToBeShown = true;
      queen = new Queen(CARROM_BOARD_WIDTH/2, CARROM_BOARD_HEIGHT/2 - 5, CARROM_MEN_RADIUS, IS_RED, queenSound);
      return false;
    }
  }
  return false;
  
}
public void resetAll(int resetMode)
{
  //Check the coin list here? 
  for (int i=0; i<currentShotLog.size(); i++)
  {
    Integer currentInteger = currentShotLog.get(i);
    //println(currentInteger.intValue());
  }
  
  boolean t = checkIfQueenIsPocketedForReal();
  if (resetMode == FORCED_RESET)
  {
    striker.resetPosition();
  }else if(resetMode == NATURAL_RESET)
  {
    striker.resetPosition();
    queen.resetVelocity();
    for(CarromMen whiteM : whiteMen)
    {
      whiteM.resetVelocity();
    }
    for(CarromMen blackM : blackMen)
    {
      blackM.resetVelocity();
    }
  }      
}

public void removePocketed()
{ 
  if(queen.isDone() && isQueenToBeShown == true) // If queen is pockted destory the instance. if the queen is not followed up by black a new instance is spawned 
  {
    isQueenToBeShown = false;
    queen.killBody();
    currentShotLog.add(new Integer(QUEEN_SHOT)); 
  }
  for(int i = whiteMen.size()-1; i>=0; i--)
  {
    CarromMen whiteM = (CarromMen)whiteMen.get(i);
    if(whiteM.isDone()) // if white coin is pocketed remove it from the list. update white score 
    {
      whiteScored++;
      currentShotLog.add(new Integer(WHITE_SHOT));
      whiteMen.remove(i);
      if(whiteScored == NUM_CARROM_WHITEMEN) // if whiteMen scored == total number of white men then player loses, set gameover flag
      {
        isGameOver = true;
        finalResult = LOSE_RESULT;
      }
    }
  }
   for(int i = blackMen.size()-1; i>=0; i--)
  {
    CarromMen blackM = (CarromMen)blackMen.get(i);
    if(blackM.isDone()) // if black goes in, the blackscore is updated
    {
      blackScored++;
      if(isAIModeOn) // if ai or gravity is on, give bonus points
      {
        bonusPoint++;
      }
      if( isGravityOn)
      {
       bonusPoint++;
      }
      if(isObsMove)
      {
       bonusPoint++;
      }
     
      currentShotLog.add(new Integer(BLACK_SHOT));
      blackMen.remove(i);
      if(blackScored == NUM_CARROM_BLACKMEN) // if all black coins have been pocketed
      {
        if(level < MAX_LEVEL)  // and if the level is still not the last level
        {  
          // check if the queen was scored by Black. Or if the queen was scored by White, then see if at 2 xtra bonus points were scored. If so, the go to next level
          if(queenScoreB == 2 || (queenScoreW == 2 && ((blackScored + bonusPoint) >= (NUM_CARROM_BLACKMEN+2)))) // The queen was scored by black, therefore proceed to next level or the queen was scored by white but black managed to grab bonus points so therefore success
          {
            level++;
            resetForNewLevel(level);
            startFlag = TRANSITION_PAGE;
            //finalResult = WIN_RESULT;
          }
          else
          {
            isGameOver = true;
            finalResult = LOSE_RESULT;
          }
        }else if(level == MAX_LEVEL)
          {
            if(queenScoreB == 2 || (queenScoreW == 2 && ((blackScored + bonusPoint) >= (NUM_CARROM_BLACKMEN+2)))) // The queen was scored by black, therefore proceed to next level or the queen was scored by white but black managed to grab bonus points so therefore success
            {
              isGameOver = true;
              finalResult = WIN_RESULT;
            }
            else
            {
              isGameOver = true;
              finalResult = LOSE_RESULT;
            }
            
          }
        }
      }
    }
  }  

public void unmuteSounds()
{
  for(CarromMen whiteM : whiteMen)
    {
      whiteM.sound.unmute();
    }
    for(CarromMen blackM : blackMen)
    {
      blackM.sound.unmute();
    }
    
    if(isQueenToBeShown == true)
    {
      queen.sound.unmute();
    }
    striker.sound.unmute();
}

public void randomizePhysicsParamsCarromMen() // For level 2 randomize physics params for the coins.
{
    for(CarromMen whiteM : whiteMen)
    {
      whiteM.b.setLinearDamping(2*random(LINEAR_DAMPING_CARROMMEN) + 0.1f);
      whiteM.b.setAngularDamping(2*random(ANGULAR_DAMPING_CARROMMEN) + 0.1f);
      whiteM.b.getFixtureList().setRestitution(random(1));
    }
    for(CarromMen blackM : blackMen)
    {
      blackM.b.setLinearDamping(2*random(LINEAR_DAMPING_CARROMMEN) + 0.1f);
      blackM.b.setAngularDamping(2*random(ANGULAR_DAMPING_CARROMMEN) + 0.1f);
      blackM.b.getFixtureList().setRestitution(random(1));
    }
    if(isQueenToBeShown == true)
    {
      queen.b.setLinearDamping(2*random(LINEAR_DAMPING_CARROMMEN) + 0.1f);
      queen.b.setAngularDamping(2*random(ANGULAR_DAMPING_CARROMMEN) + 0.1f);
      queen.b.getFixtureList().setRestitution(random(1));
    }
}
public void resetForNewLevel(int levelNumber)
{
  //reset scores;
  whiteScored = 0;
  blackScored = 0;
  queenScoreB = 0;
  queenScoreW = 0;
  strikerChancesLeft = MAX_STRIKER_CHANCES;
  queenStatus = "";
  bonusPoint = 0;
  
  //reset boolean
  isAIModeOn = true; // In LEVEL 1 have ai mode on all the time.   
  isGravityOn = false;
  isQueenToBeShown = true;
  isGameOver = false;
  isQueenPocketed = false;
  
  // reset arrays.
  currentShotLog.clear();
  currentShotLog = null;
  
  whiteMen.clear();
  whiteMen = null;
  
  blackMen.clear();
  blackMen = null;
  
  createShotLogArray();
  setCoinCoords();
  getCoinsReady();
  addObstructions();
  
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#cccccc", "CrazyCarrom" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
